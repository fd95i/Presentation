﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour {

    public float aceleracion;
    public Text textCount;
    public Text textWin;

    private Rigidbody rigid;
    private int count;

    // Use this for initialization
    void Start () {
        rigid = gameObject.GetComponent<Rigidbody>();
        count = 0;
        SetCountText();
        textWin.text = "";
    }
	
	// Update is called once per frame
	void FixedUpdate () {
        bool w = Input.GetKey("w");
        bool s = Input.GetKey("s");
        bool a = Input.GetKey("a");
        bool d = Input.GetKey("d");


        if (rigid != null)
        {
            if (w)
            {
                rigid.AddForce(aceleracion * new Vector3(0.0f, 0.0f, 1.0f));
            }
            if (s)
            {
                rigid.AddForce(aceleracion * new Vector3(0.0f, 0.0f, -1.0f));
            }
            if (a)
            {
                rigid.AddForce(aceleracion * new Vector3(-1.0f, 0.0f, 0.0f));
            }
            if (d)
            {
                rigid.AddForce(aceleracion * new Vector3(1.0f, 0.0f, 0.0f));
            }
        }

	}

    void OnTriggerEnter(Collider other)
    {
        // ..and if the game object we intersect has the tag 'Pick Up' assigned to it..
        if (other.gameObject.CompareTag("Pick Up"))
        {
            // Make the other game object (the pick up) inactive, to make it disappear
            other.gameObject.SetActive(false);

            // Add one to the score variable 'count'
            count = count + 1;

            // Run the 'SetCountText()' function (see below)
            SetCountText();
        }
    }

    void SetCountText()
    {
        textCount.text = "Puntos: " + count.ToString();


        if (count >= 12)
        {
            textWin.text = "Ganaste!";
        }
    }
}

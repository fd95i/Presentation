#ifndef SYMBOL_H_INCLUDED
#define SYMBOL_H_INCLUDED

int Temp;
int estaDefinido(char * id);
void aniadir(char * id);

#endif

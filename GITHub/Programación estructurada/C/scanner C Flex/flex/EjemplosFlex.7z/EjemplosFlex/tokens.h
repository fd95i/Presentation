enum token {HEXA, DECIMAL, OCTAL, REAL};
